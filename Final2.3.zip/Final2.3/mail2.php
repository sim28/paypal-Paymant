﻿<?php
$url = $_GET['url'];
$email = $_GET['email'];
$price = $_GET['price'];
$name = $_GET['name'];

require ('PHPMailer/PHPMailerAutoload.php');


$mail = new PHPMailer();

$mail->Host = "smtp.gmail.com";

//$mail->isSMTP();

$mail->SMTPAuth = true;

$mail->Username = "fastfollowers.contact@gmail.com";

$mail->Password = "Sample123@!";

$mail->SMTPSecure = 'ssl';

$mail->Port = 465;

$mail->Subject = 'FASTFOLLOWES.NET ORDER RECEIVED';

$mail->Body = 'Thank for your ordering from FastFollowers.net. Here’s your order details:
URL: ' .$url. '
PRICE: ' . $price . '

If you have questions and clarifications please don’t hesitate to contact us at https://fastfollowers.net/contact.html';

$mail->setFrom('admin@fastfollowers.net', 'ADMIN@FASTFOLLOWERS.NET');

$mail->addAddress($email);

if($mail->send()){
    echo "<script type='text/javascript'>window.location.href = 'https://fastfollowers.net/instagram.php?success=true';</script>";
}
else{
    echo "<script type='text/javascript'>window.location.href = 'https://fastfollowers.net/instagram.php?fail=false';</script>";
}



?>