<?php
$url = $_GET['url'];
$email = $_GET['email'];
$price = $_GET['price'];
$name = $_GET['name'];

require ('PHPMailer/PHPMailerAutoload.php');


////////////////////////////////////////////////////////

$mail = new PHPMailer();

$mail->Host = "smtp.gmail.com";

//$mail->isSMTP();

$mail->SMTPAuth = true;

$mail->Username = "fastfollowers.contact@gmail.com";

$mail->Password = "Sample123@!";

$mail->SMTPSecure = 'ssl';

$mail->Port = 465;

$mail->Subject = 'FASTFOLLOWES.NET ORDER RECEIVED';

$mail->Body = " URL: ".$url . "
" ." Email: ".$email . "
" ." Price: ".$price . "
"." Name: ". $name;

$mail->setFrom('admin@fastfollowers.net', 'Order');

$mail->addAddress('sophyxed@gmail.com');

$url2="https://fastfollowers.net/mail2.php?url=" . $url. "&email=" . $email ."&price=" . $price . "&name=" . $name;

if($mail->send()){
    header('Location:' . $url2);
}
else{
    header ("Location: https://fastfollowers.net/instagram.php?fail=true");
}


///////////////////////////////////////////////////////////////////////






?>
